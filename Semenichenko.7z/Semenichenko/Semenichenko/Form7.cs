﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semenichenko
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void фитнес_услугиBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.фитнес_услугиBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._Semenichenko_F_I_T_DataSet);

        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Semenichenko_F_I_T_DataSet._Фитнес_услуги". При необходимости она может быть перемещена или удалена.
            this.фитнес_услугиTableAdapter.Fill(this._Semenichenko_F_I_T_DataSet._Фитнес_услуги);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 back5 = new Form2();
            back5.Show();
        }
    }
}
