﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semenichenko
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void тренировкаBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.тренировкаBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._Semenichenko_F_I_T_DataSet);

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Semenichenko_F_I_T_DataSet.Тренировка". При необходимости она может быть перемещена или удалена.
            this.тренировкаTableAdapter.Fill(this._Semenichenko_F_I_T_DataSet.Тренировка);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 back4 = new Form2();
            back4.Show();
        }
    }
}
