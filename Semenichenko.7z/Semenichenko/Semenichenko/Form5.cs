﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Semenichenko
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_Semenichenko_F_I_T_DataSet.Специалисты". При необходимости она может быть перемещена или удалена.
            this.специалистыTableAdapter.Fill(this._Semenichenko_F_I_T_DataSet.Специалисты);

        }

        private void специалистыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.специалистыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this._Semenichenko_F_I_T_DataSet);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 back3 = new Form2();
            back3.Show();
        }
    }
}
